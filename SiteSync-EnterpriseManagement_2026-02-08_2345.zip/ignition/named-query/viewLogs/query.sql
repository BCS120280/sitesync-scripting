select * from logs
order by sqltime desc