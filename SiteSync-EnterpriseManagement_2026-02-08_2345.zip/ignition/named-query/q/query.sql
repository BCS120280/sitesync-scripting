update devices 
set tenantID = 2
where devEUI in (



SELECT d.devEUI FROM Devices d left join tagpaths t on t.devEUI = d.devEUI
where t.tagPathBase = 'GVL')