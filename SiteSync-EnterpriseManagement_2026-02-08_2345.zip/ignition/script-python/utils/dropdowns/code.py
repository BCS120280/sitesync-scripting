def formatDropdownOption(label, value):
	format = {
	"label":label, 
	"value":value
	}
	return format
	
