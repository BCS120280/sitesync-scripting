def getInt(boolean):
	if boolean == False:
		return 0
	else:
		return 1
		
		
def getBool(number):
	if number == 0:
		return False
	else:
		return True