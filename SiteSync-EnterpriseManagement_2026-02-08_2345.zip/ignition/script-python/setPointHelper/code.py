def applyToEngHigh(engineeringHigh, tagPaths):
	return False
	
def applyToEngLow(engineerLow, tagPaths):
	return False
	
def applyToTagValue(tagValue, tagPaths):
	return False
	
