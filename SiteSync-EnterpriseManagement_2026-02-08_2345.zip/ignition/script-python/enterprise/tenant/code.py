import json
def getDefaultApp():
	return 3
#	j = system.sitesync.getPrimaryNetworkServerAccount()
#	if j != "null":
#		app = json.loads(j)
#		return app['id']
#	else:
#		return -16